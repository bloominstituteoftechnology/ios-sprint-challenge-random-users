//
//  UserDetailViewController.swift
//  Random Users
//
//  Created by Lambda_School_Loaner_268 on 4/10/20.
//  Copyright © 2020 Erica Sadun. All rights reserved.
//

import UIKit

class UserDetailViewController: UIViewController {
    
    // MARK: - OUTLETS
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var phoneNumberLabel: UILabel!
    
    @IBOutlet weak var emailLabel: UILabel!
    
    // MARK: - PROPERTIES
    var user: User! {
        didSet {
            updateViews()
        }
    }
    
    // MARK: - METHODS
    
    private func updateViews() {
        if isViewLoaded {
            nameLabel.text = user.name.fullName
            phoneNumberLabel.text = user.phone
            emailLabel.text = user.phone
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
