//
//  FetchUsersController.swift
//  Random Users
//
//  Created by Lambda_School_Loaner_268 on 4/10/20.
//  Copyright © 2020 Erica Sadun. All rights reserved.
//

import Foundation
import UIKit

class FetchRandomUsersController {
func fetchRandomUsers(using session: URLSession = URLSession.shared,
                      completion: @escaping ([User]?, Error?) -> Void) {
    
    let url = URL(string: "https://randomuser.me/api/?format=json&inc=name,email,phone,picture&results=1000")!
    
    fetch(from: url, using: session) { (results: RandomUserResults?,
        error: Error?) in guard error == nil else {
            completion(nil, error!)
            return
        }
        guard let users = results?.results else {
            completion(nil, NSError())
            return
        }
        completion(users, nil)
    }
}
   
func fetchPhotos(from pictureURL: URL,
                 using session: URLSession = URLSession.shared,
                 completion: @escaping (UIImage?, Error?) -> Void) {
    
    fetch(from: pictureURL, using: session) { (imageData: Data?, error: Error?) in guard let imageData = imageData else {
            completion(nil, error)
            return
        }
        guard let pic = UIImage(data: imageData) else {
            completion(nil, error)
        }
        completion(pic, nil)
   }
}
   

private func fetch<T: Codable>(from url: URL,
                       using session: URLSession = URLSession.shared,
                       completion: @escaping (T?, Error?) -> Void) {
    session.dataTask(with: url) { (data, response, error) in
        if let error = error {
            completion(nil, error)
            return
        }
        
        guard let data = data else {
            completion(nil, NSError(domain: "com.LambdaSchool.RandomUsers.ErrorDomain", code: -1, userInfo: nil))
            return
        }
        
        do {
            
            let decodedObject = try JSONDecoder().decode(T.self, from: data)
            completion(decodedObject, nil)
        } catch {
            completion(nil, error)
        }
    }.resume()
}
}
