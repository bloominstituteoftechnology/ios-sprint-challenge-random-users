//
//  User.swift
//  Random Users
//
//  Created by Lambda_School_Loaner_268 on 4/10/20.
//  Copyright © 2020 Erica Sadun. All rights reserved.
//

import Foundation

struct Photo: Codable {
    var large: URL
    var medium: URL
    var thumbnail: URL
}

struct User {
    var name: Name
    var email: String
    var phone: String
    var photo: Photo
}

// Expanded Data
struct Name {
    var title: String
    var first: String
    var last: String
    var fullName: String {
        "\(title) \(first) \(last)"
    }


}

