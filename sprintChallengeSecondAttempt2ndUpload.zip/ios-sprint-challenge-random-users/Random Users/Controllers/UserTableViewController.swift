//
//  UserTableViewController.swift
//  Random Users
//
//  Created by Lambda_School_Loaner_268 on 4/10/20.
//  Copyright © 2020 Erica Sadun. All rights reserved.
//

import UIKit

class UserTableViewController: UITableViewController {
    
    // MARK: - PROPERTIES
    
    var users = [User]() {
        didSet {
            DispatchQueue.main.async {
                self.tableView?.reloadData()
            }
        }
    }
    
    private let fetchUserController = FetchRandomUsersController()
    
    private var cache = Cache<URL, UIImage>()
    
    private let fetchPictureQueue = OperationQueue()
    
    private var fetchPictureOps = [URL : Operation]()
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        fetchUserController.fetchRandomUsers { (users, error) in
            guard error == nil else {
                NSLog("Error Fetching Users: \(error!)")
                return
            }
            guard let users = users else {
                NSLog("Error Fetching Users!")
                return
            }
            self.users = users
        }
    }

    

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return users.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "userCell", for: indexPath) as? UserTableViewCell ?? UserTableViewCell()
        let user = users[indexPath.row]
        cell.user = user
        
        let thumbnailURL = user.picture.thumbnail
        loadThumbnail(at: thumbnailURL, forCell: cell, forRowAt: indexPath)
        
        let largeURL = user.picture.large
        cacheImage(at: largeURL, forCell: cell, forRowAt: indexPath)

        return cell
    }
    
   override func tableView(_ tableView: UITableView, didEndDisplaying cell: UITableViewCell, forRowAt indexPath: IndexPath) {
       let thumbnailURL = users[indexPath.row].picture.thumbnail
       if let operation = fetchPictureOps[thumbnailURL] {
           operation.cancel()
       }

       let largeURL = users[indexPath.row].picture.large
       if let operation = fetchPictureOps[largeURL] {
           operation.cancel()
       }
   }

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "tableToDetail",
            let detailVC = segue.destination as? UserDetailViewController,
            let indexPath = tableView.indexPathForSelectedRow else {
                return
        }
        let user = users[indexPath.row]
        detailVC.user = user
        
        let largePicture = user.picture.large
        
        loadLargePicture(at: largePicture, forDetailVC: detailVC)
        }
    
    private func loadThumbnail(at url: URL, forCell cell: UserTableViewCell, forRowAt indexPath: IndexPath, isThumbnail: Bool = false) {

        if let picture = cache.value(for: url) {
            DispatchQueue.main.async { cell.thumbnailIV.image = picture }
                return
        }
        
        let fetchPictureOperation = FetchPictureOperation(imageURL: url)
        
        let cacheOperation = BlockOperation {
            if let data = fetchPictureOperation.data,
                let picture = UIImage(data: data) {
                self.cache.cache(value: picture, for: url)
            }
            
        }

            let setPictureOperation = BlockOperation {
                if let currentIndexPath = self.tableView.indexPath(for: cell) {
                    guard currentIndexPath == indexPath else { return }
                }
                if let data = fetchPictureOperation.data,
                    let picture = UIImage(data: data) {
                    DispatchQueue.main.async { cell.thumbnailIV.image = picture }
                }
            }


            cacheOperation.addDependency(fetchPictureOperation)
            setPictureOperation.addDependency(fetchPictureOperation)

            fetchPictureOperation.queuePriority = .high
            cacheOperation.queuePriority = .high
            setPictureOperation.queuePriority = .high


            fetchPictureQueue.addOperations([fetchPictureOperation, cacheOperation], waitUntilFinished: false) // false = async
            OperationQueue.main.addOperations([setPictureOperation], waitUntilFinished: false)
            fetchPictureOps[url] = fetchPictureOperation
        }

        private func cacheImage(at url: URL, forCell cell: UserTableViewCell, forRowAt indexPath: IndexPath, isThumbnail: Bool = false) {
            guard cache.value(for: url) == nil else { return }


            let fetchPictureOperation = FetchPictureOperation(imageURL: url)

            let cacheOperation = BlockOperation {
                if let data = fetchPictureOperation .data,
                    let picture = UIImage(data: data) {
                    self.cache.cache(value: picture, for: url)
                }
            }

            // Add dependencies
            cacheOperation.addDependency(fetchPictureOperation)
            if isThumbnail {
                fetchPictureOperation.queuePriority = .high
                cacheOperation.queuePriority = .high
            }

            // Start operations
            fetchPictureQueue.addOperations([fetchPictureOperation, cacheOperation], waitUntilFinished: false) // false = async
            fetchPictureOps[url] = fetchPictureOperation
        }

        private func loadLargePicture(at url: URL, forDetailVC detailVC: UserDetailViewController) {

            if let picture = cache.value(for: url) {

                DispatchQueue.main.async { detailVC.imageView.image = picture }
                return
            }

            // Set up operations
            let fetchPictureOperation = FetchPictureOperation(imageURL: url)

            let cacheOperation = BlockOperation {
                if let data = fetchPictureOperation.data,
                    let picture = UIImage(data: data) {
                    self.cache.cache(value: picture, for: url)
                }
            }

            let setPictureOperation = BlockOperation {
                if let data = fetchPictureOperation.data,
                    let picture = UIImage(data: data) {
                    DispatchQueue.main.async { detailVC.imageView.image = picture }
                }
            }

            // Add dependencies and queue priorities
            cacheOperation.addDependency(fetchPictureOperation)
            setPictureOperation.addDependency(fetchPictureOperation)

            fetchPictureOperation.queuePriority = .veryHigh
            cacheOperation.queuePriority = .veryHigh
            setPictureOperation.queuePriority = .veryHigh

            // Start operations
            fetchPictureQueue.addOperations([fetchPictureOperation, cacheOperation], waitUntilFinished: false) // false = async
            OperationQueue.main.addOperations([setPictureOperation], waitUntilFinished: false)
            fetchPictureOps[url] = fetchPictureOperation
    }
    
    

}
