//
//  FetchPhotoOperation.swift
//  Random Users
//
//  Created by Lambda_School_Loaner_268 on 4/10/20.
//  Copyright © 2020 Erica Sadun. All rights reserved.
//

import Foundation
class FetchPictureOperation: ConcurrentOperation {
    
    // MARK: - INIT
    init(imageURL: URL) {
           self.imageURL = imageURL
           super.init()
       }
    
    // MARK: - PROPERTIES
    var imageURL: URL
    
    var data: Data?
    
    private var task: URLSessionDataTask?
    
    
   // MARK: - OVERRIDES
    override func start() {
        state = .isExecuting
        fetchPhoto()
        task?.resume()
    }
    
    override func cancel() {
        state = .isFinished
        fetchPhoto()
        task?.cancel()
    }
    
    // MARK: - METHODS
    func fetchPhoto() {
        task = URLSession.shared.dataTask(with: imageURL) { (data, _, error) in
            defer {
                self.state = .isFinished
            }
            if let error = error {
                print(error)
                return
            }
            guard let data = data else {
                print("No data")
                return
            }
            self.data = data
        }
    }
}
