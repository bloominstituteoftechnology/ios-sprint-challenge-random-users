//
//  UserDetailViewController.swift
//  Random Users
//
//  Created by Lambda_School_Loaner_268 on 4/10/20.
//  Copyright © 2020 Erica Sadun. All rights reserved.
//

import UIKit

class UserDetailViewController: UIViewController {
    
    // MARK: - OUTLETS
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var phoneNumberLabel: UILabel!
    
    @IBOutlet weak var emailLabel: UILabel!
    
    @IBOutlet weak var nameTF: UITextField!
    
    @IBOutlet weak var phoneTF: UITextField!
    @IBOutlet weak var emailTF: UITextField!
    // MARK: - PROPERTIES
    var user: User! {
        didSet {
            updateViews()
        }
    }
    
    // MARK: - METHODS
    
    private func updateViews() {
        guard let user = user else {
            print("user not getting ported")
            return
        }
        print(user.name.fullName)
        self.nameTF.text = user.name.fullName
        self.phoneTF.text = user.phone
        self.emailTF.text = user.email
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateViews()

        // Do any additional setup after loading the view.
    }

}
